## server.R
library(shiny)
library(plotly)
library(dplyr)
library(reshape2)
library(leaflet)
#setwd("E:\\IPL")

bowler_wickets<-read.csv("bowler_wickets.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)

batsmen_data_frame<-read.csv("batsmen_data_frame.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)

Yearly_IPL_Winner<-read.csv("Yearly_IPL_Winner.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)

Season_win_counts<-read.csv("Season_win_counts.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)

seasonal_bat_first_second<-read.csv("seasonal_bat_first_second.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)

bowler_df<-read.csv("bowler_df.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)


playerprofile<-read.csv("playerprofile.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)


stadium_df<-read.csv("stadium_df.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)


Team_final<-read.csv("Team_final.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)

Team_final<-Team_final[Team_final$win!='NA',]

Team_final$win<-as.numeric(Team_final$win)

Team_final$loss<-as.numeric(Team_final$loss)

Team_final$toss_win=ifelse(Team_final$batting_team==Team_final$toss_winner,1,0)

team_stats<-read.csv("team_stats.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)


match_seasonal<-read.csv("match_seasonal.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)

shinyServer(function(input, output) {
  
  
  #season page
  output$Winner_image <- renderUI({
    tags$img(src = paste0(Yearly_IPL_Winner[Yearly_IPL_Winner$Year==input$Year_ID,'Winner'], ".png"),width = "284px", height = "284px")
  })
  
  output$bar_seasonal<-renderPlotly({
    t=head(batsmen_data_frame%>%filter(match_year==input$Year_ID),input$Num_Player_ID)
    t$batsman <- factor(t$batsman, levels = t$batsman)
    p1<-plot_ly( x = t$batsman,
      y =t$Total_runs,
      type = "bar",
     # text=t$average,
      color = I("orange"),
      name='Batsman')
    t=head(bowler_wickets%>%filter(match_year==input$Year_ID),input$Num_Player_ID)
    t$bowler <- factor(t$bowler, levels = t$bowler)
    p2<-plot_ly( x = t$bowler,
             y =t$Total_wickets,
             type = "bar",
             color = I("purple"),
             name='Bowler')
    
    p<-subplot(p1,p2)%>% layout(annotations = list(
      list(x = 0.2 , y = 1.05, text = "Top Run getters by Season", showarrow = F, xref='paper', yref='paper'),
      list(x = 0.8 , y = 1.05, text = "Top Wicket Takers by Season", showarrow = F, xref='paper', yref='paper'))
    )
    })  
  
  output$pie_seasonal<-renderPlotly({
      
      ds1<-Season_win_counts%>%filter(season==input$Year_ID)    
      
      
      t2<-seasonal_bat_first_second%>%filter(match_year==input$Year_ID)    
      ds2<-melt(data = t2, id.vars = c("match_year"), measure.vars = c("bat_first","bat_second","tied_no_result_super_over"))
      colnames(ds2)[colnames(ds2)=="variable"] <- "variable1"
      colnames(ds2)[colnames(ds2)=="value"] <- "value1"
      
      p1 <- plot_ly()%>%add_pie(name="Team_matches",labels = ds1$winner,textposition = 'inside',
                                textinfo = 'label+percent',
                                insidetextfont = list(color = '#FFFFFF'), values = ds1$Number_of_matches_won,domain = list(row = 0, column = 0),name='Team_matches')%>%
        add_pie(name="Inning Win Percentage", labels = ds2$variable1, values = ds2$value1,textposition = 'inside',
                textinfo = 'label+percent',
                insidetextfont = list(color = '#FFFFFF'),domain = list(row = 0, column = 1),name='Win Percentage')%>%
        layout(title = "Team matches won                                                                                         Innings Win Percentage", showlegend = F,
               grid=list(rows=1, columns=2),
               xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
               yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
   })  
  output$d3 <- renderD3({
    t=head(batsmen_data_frame%>%filter(match_year==input$Year_ID),input$Num_Player_ID)
    
    r2d3(
      data=c(0.3, 0.6, 0.8, 0.95, 0.40, 0.20),
      script = "barchart.js"
    )
  })
  
  
  
  #batsman page
  output$bar_batsman<-renderPlotly({
      ay2<-list(zeroline = FALSE,
                showline = FALSE,
                showticklabels = FALSE,
                showgrid = FALSE)
      ay <- list(
      tickfont = list(color = "red"),
      overlaying = "y",
      side = "right",
      title = "",
      zeroline = FALSE,
      showline = FALSE,
      showticklabels = FALSE,
      showgrid = FALSE
    )
      t=batsmen_data_frame%>%filter(batsman==input$batter_name)
      p1<-plot_ly( x = t$match_year)%>%
          add_trace(y =t$Total_runs,
                 type = "bar",
                 # text=t$average,
                 color = I("orange"),
                 name='Total')%>%
        add_trace(   y = t$average, 
                     type = 'scatter', 
                     mode = 'lines+markers',
                     color = I("red"),
                     name='Average',
                     yaxis = "y2")%>%
        add_trace(   y = t$Strike_Rate, 
                     type = 'scatter', 
                     mode = 'lines+markers',
                     color = I("blue"),
                     name='Strike_Rate',
                     yaxis = "y2")%>% layout(yaxis=ay2,
                        yaxis2 = ay,
                       xaxis = list(title="Year")
                     )
    
  })
  output$pie_batsman<-renderPlotly({
    bat_score<-batsmen_data_frame[c("batsman","match_year", "Fours","Sixes","Others")]
    t1<-bat_score%>%filter(match_year==input$Year_ID1&batsman==input$batter_name)    
    ds1<-melt(data = t1, id.vars = c("match_year"), measure.vars = c("Fours","Sixes","Others"))
    
    
    dis_type<-batsmen_data_frame[c("batsman","match_year","bowled","caught","caught.and.bowled","lbw","run.out","stumped")]
    t2<-dis_type%>%filter(match_year==input$Year_ID1&batsman==input$batter_name)   
    ds2<-melt(data = t2, id.vars = c("match_year"), measure.vars = c("bowled","caught","caught.and.bowled","lbw","run.out","stumped"))
    colnames(ds2)[colnames(ds2)=="variable"] <- "variable1"
    colnames(ds2)[colnames(ds2)=="value"] <- "value1"
    
    p1 <- plot_ly()%>%add_pie(name="Boundries Percentage",labels = ds1$variable, values = ds1$value,textposition = 'inside',
                              textinfo = 'label+percent',
                              insidetextfont = list(color = '#FFFFFF'),domain = list(row = 0, column = 0),name='Boundries')%>%
      add_pie(hole = 0.5,name="Dismissal Type", labels = ds2$variable1, values = ds2$value1,textposition = 'inside',
              textinfo = 'label+percent',
              insidetextfont = list(color = '#FFFFFF'),domain = list(row = 0, column = 1),name='Dismissal')%>%
      layout(title = "Boundries Percentage                                                                                        Dismissal Type", showlegend = F,
             grid=list(rows=1, columns=2),
             xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
             yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
  }) 

  output$batsman_image <- renderUI({
    tags$img(src = paste0(input$batter_name, ".png"),width = "284px", height = "284px")
  })
  
  output$batter_tbl <- renderTable({ 
    playerprofile%>%filter(PLAYER==input$batter_name)%>%melt(id.vars = c("PLAYER"), measure.vars = c("Role","Batting_Style","Bowling_Style","Nationality","Batting_Matches","Batting_Innings","Batting_Runs","High_Score", "Batting_Average","Batting_Strike_Rate","Hundreds","Fifties"))%>%select(variable,value)%>%na.omit()
    },digits = 2, na = 'missing',colnames = FALSE)  

  
  
  
  
  #bowler page
  output$bar_bowler<-renderPlotly({
    ay2<-list(zeroline = FALSE,
              showline = FALSE,
              showticklabels = FALSE,
              showgrid = FALSE)
    ay <- list(
      tickfont = list(color = "red"),
      overlaying = "y",
      side = "right",
      title = "",
      zeroline = FALSE,
      showline = FALSE,
      showticklabels = FALSE,
      showgrid = FALSE
    )
    t=bowler_df%>%filter(bowler==input$bowler_name)
    #names(bowler_df)
    t<-t[c("match_year","Runs_Conceded","Extras_Conceded", "Balls","Total_Wickets"  )]
    df<-t%>%group_by(match_year)%>%mutate(Matches=1)%>%summarise_all(sum)%>%mutate(Season_Economy=(Runs_Conceded/Balls)*6)
    p1<-plot_ly( x = df$match_year)%>%
      add_trace(y =df$Matches,
                type = "bar",
                # text=t$average,
                color = I("blue"),
                name='Total Matches')%>%
      add_trace(y = df$Total_Wickets,type="bar" ,name = 'Total_Wickets', color = I("purple")) %>%
      add_trace(   y = df$Season_Economy, 
                   type = 'scatter', 
                   mode = 'lines+markers',
                   color = I("red"),
                   name='Economy',
                   yaxis = "y2")%>%
      add_trace(   y = df$Extras_Conceded, 
                   type = 'scatter', 
                   mode = 'lines+markers',
                   color = I("green"),
                   name='Extras_Conceded',
                   yaxis = "y2")%>% layout(yaxis=ay2,
                                           yaxis2 = ay,
                                           xaxis = list(title="Year")
                   )
    
  })
  
  output$bowler_image <- renderUI({
    tags$img(src = paste0(input$bowler_name, ".png"),width = "284px", height = "284px")
  })
  
  output$bowler_tbl <- renderTable({ 
    playerprofile%>%filter(PLAYER==input$bowler_name)%>%melt(id.vars = c("PLAYER"), measure.vars = c("Role","Batting_Style","Bowling_Style","Nationality", "Bowler_Matches","Bowler_Innings","Bowler_Runs","Wickets","Best","Economy","Average","Strike_Rate","Five_Wickets"))%>%select(variable,value)%>%na.omit()
  },digits = 2, na = 'missing',colnames = FALSE)  
  
  
  #### Stadium Page
  output$mymap <- renderLeaflet({
    stadiumIcon <- makeIcon(
      iconUrl = "stadium.png",
      iconWidth = 30, iconHeight = 30
    )
    
    
    stadia<-stadium_df%>%filter(season==input$Year_ID3)
    labs <- lapply(seq(nrow(stadia)), function(i) {
      paste0( '<p><h5>', stadia[i, "venue"], ' ',stadia[i, "city"],'</h5><p>', 
             '<h5>', stadia[i, "matches"], ' Matches </h5>') 
    })
    leaflet(stadia) %>% addTiles() %>%
      addMarkers(~long, ~lat, label = lapply(labs, HTML),icon = stadiumIcon)
    
    })
  
  output$bar_stadium<-renderPlotly({
    t1<-match_seasonal%>%filter(season==input$Year_ID3)
    t2<-t1%>%select(season,city,Total_Runs,Dismissals)%>%group_by(season,city)%>%summarise_all(mean)
    
    t3<-t2%>%arrange(Total_Runs)
    t4<-t2%>%arrange(desc(Dismissals))
    
    t3$city <- factor(t3$city, levels = t3$city)
    t4$city <- factor(t4$city, levels = t4$city)
    
    p1<-plot_ly( y = t3$city,
                 x =t3$Total_Runs,
                 type = "bar", marker = list(
                   color = ~t3$Total_Runs,
                   colorscale='Blues',reversescale =T
                 ),
                 name='Average Runs',orientation = 'h')
    p2<-plot_ly( y = t4$city,
                 x =t4$Dismissals,
                 type = "bar",
                 marker = list(
                   color = ~t4$Dismissals,
                   colorscale='Reds'
                 ),
                 name='Average Wickets',orientation = 'h')
    
    p<-subplot(p1,p2)%>% layout(showlegend = F,annotations = list(
      list(x = 0.2 , y = 1.05, text = "Average runs scored in a match", showarrow = F, xref='paper', yref='paper'),
      list(x = 0.8 , y = 1.05, text = "Average dismissals in a match", showarrow = F, xref='paper', yref='paper'))
    )
  }) 
  
  
  output$stadium_image <- renderUI({
    tags$img(src = "cricket_ground.png",width = "284px", height = "284px")
  })
  
  
  
  
  
  
  
  
  #### Team page
  output$Team_image <- renderUI({
    tags$img(src = paste0(input$Team_ID, ".png"),width = "284px", height = "284px")
  })
  output$bar_team<-renderPlotly({
    t=Team_final%>%filter(batting_team==input$Team_ID)%>%group_by(bowling_team)%>%summarise(matches=n(),wins=sum(win,na.rm = T),losses=sum(loss,na.rm = T))
    p1<-plot_ly( y = t$bowling_team,orientation = 'h')%>%
      add_trace(x = t$wins,type="bar" ,name = 'Wins', color = I("blue"),text=paste(as.character(t$matches)," Matches")) %>%
      add_trace(   x = t$losses, 
                   type = 'bar', 
                   color = I("red"),text=paste(as.character(t$matches)," Matches"),
                   name='Losses')%>% layout(barmode = 'stack',yaxis = list(title="Opposing Teams")
                   )
  })
  output$team_tbl <- renderTable({ 
    team_stats%>%filter(Team==input$Team_ID)%>%melt(id.vars = c("Team"), measure.vars = c("Matches","Won","Lost","SuperOver_Win", "SuperOver_Loss","NR","Win_Percentage","Titles","Highest_Score","Lowest_Score","Highest_Run_Chase"))%>%select(variable,value)%>%na.omit()
  },digits = 2, na = 'missing',colnames = FALSE) 
  output$scatter_team<-renderPlotly({
    sc<-Team_final%>%filter(match_year==input$Year_ID4)%>%group_by(match_year,batting_team)%>%summarise(Highest_Score=max(Innings_score),toss_wins=sum(toss_win),wins=sum(win))
    
    
    p1 <- plot_ly(data = sc, x = ~wins,size=~wins, y = ~Highest_Score,type='scatter',  text = ~paste("Wins: ", wins, '<br>Highest Score:', Highest_Score),mode='markers', color = ~batting_team,colors='Set1')           
    
    p2 <- plot_ly(data = sc, x = ~wins,size=~wins, y = ~toss_wins,type='scatter', text = ~paste("Wins: ", wins, '<br>Toss Wins:', toss_wins),mode='markers', color = ~batting_team,colors='Set1')           
    
    p<-subplot(p1,p2)%>% layout(showlegend = F,annotations = list(
      list(x = 0.2 , y = 1.05, text = "Wins Vs Highest Score", showarrow = F, xref='paper', yref='paper'),
      list(x = 0.8 , y = 1.05, text = "Wins Vs Toss Wins", showarrow = F, xref='paper', yref='paper'))
    )
    
  })
  
})


