############ Importing the required libraries
library(dplyr)
library(ggplot2) 
library(plotly)
library(dummies)

#### SETTING UP BY FILE IMPORT PATH
setwd("D:\\IPL\\IPL\\")


### IMPORT THE BALL BY BALL DATA
ball_by_ball<-read.csv("ball_by_ball_data.csv",header = T,sep = ",",stringsAsFactors = F)


match_data<-read.csv("match_data.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)

### MATCH TOTAL RUNS

match_runs<-ball_by_ball%>%filter(is_super_over==0)%>%group_by(match_id,match_year)%>%summarise(Runs=sum(batsman_runs),Extras=sum(extra_runs))%>%mutate(Total_Runs=Runs+Extras)

### MATCH WICKETS

match_wickets<-ball_by_ball%>%filter(!is.na(player_dismissed))%>%group_by(match_id,match_year)%>%summarise(Dismissals=n())



match_data<-match_data%>%select("match_id","season", "city","team1_id","team2_id","winner","player_of_match","venue")


match_data<-left_join(x=match_data,y=match_runs,by=c("season"="match_year","match_id"))

match_data<-left_join(x=match_data,y=match_wickets,by=c("season"="match_year","match_id"))

match_data[is.na(match_data$city),'city']='Dubai'

write.csv(x=match_data,file='match_seasonal.csv',row.names = F)

