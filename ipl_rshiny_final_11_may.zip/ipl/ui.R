## ui.R


#### Importing the required libraries
library(shiny)
library(plotly)
library(shinydashboard)
library(leaflet)
library(r2d3)


### Setting up the working directories
#setwd("E:\\IPL")


### Importing files for the drop dowm input

### Batsmen Names
batsmen_names<-read.csv("batsman_names.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)

batters<-unique(batsmen_names$Batsman)
batters<-sort(batters)

### Bowler Names
bowler_df<-read.csv("bowler_names.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)

Bowlers<-unique(bowler_df$Bowlers)
Bowlers<-sort(Bowlers)




### IPL Title Icon
title <- tags$a(href='https://www.iplt20.com/',
                tags$img(src="vivo-ipl-logo.png", height = '65', width = '125'))


### START of UI function
ui<-fluidPage(theme = "bootstrap.min.css",   ### CSS file 
  navbarPage(title=title,
             #### SEASONAL TRENDS PANE
             tabPanel("Seasonal Trends",  
                      sidebarLayout(
                          sidebarPanel(
                                selectInput(inputId = "Year_ID","Year",selected = 2017,choices = 2008:2017),
                                sliderInput(inputId="Num_Player_ID", label="Number of players", min=5, max=20,value=10),
                                "Winner",
                                uiOutput("Winner_image"),
                                fluidRow(
                                  # A static infoBox
                                  shinydashboard:::valueBox(636,"Matches Played",width = NULL),
                                  shinydashboard:::valueBox(13,"Teams participated till now",width = NULL),
                                  shinydashboard:::valueBox(85,"Mumbai hosted most number of IPL matches",width = NULL)
                                )
                                      ),
                            mainPanel(   
                                plotlyOutput("bar_seasonal"),  
                                plotlyOutput("pie_seasonal")
                                      )
                                   )
                      ),
             tabPanel("Batsman Analysis",
                      sidebarLayout(
                          sidebarPanel(
                                
                                selectInput("batter_name", "Batsman Name:", 
                                            choices=batters),
                                
                                uiOutput("batsman_image"),
                                tableOutput('batter_tbl')
                               
                                      ),
                       
                          mainPanel(
                              plotlyOutput("bar_batsman"),
                              selectInput(inputId = "Year_ID1","Season",selected = 2017,choices = 2008:2017),
                              plotlyOutput("pie_batsman")
                                    )
                                 )       
                     ),
            tabPanel("Bowler Analysis",
                     sidebarLayout(
                       sidebarPanel(
                         
                              selectInput("bowler_name", "Bowler Name:", 
                                     choices=Bowlers),
                              uiOutput("bowler_image"),
                              #selectInput(inputId = "Year_ID2","Year",selected = 2017,choices = 2008:2017),
                              tableOutput('bowler_tbl')
                                   ),
                        mainPanel(
                              plotlyOutput("bar_bowler")
                                 )
                                ) 
                    ),
            tabPanel("Stadium Analysis",
                    sidebarLayout(
                      sidebarPanel(
                           selectInput(inputId = "Year_ID3","Year",selected = 2017,choices = 2008:2017),
                           uiOutput("stadium_image"),
                           shinydashboard:::infoBox("A cricket field is a large grassy ground on which the game of cricket is played. Although generally oval in shape, there is a wide variety within this: some are almost perfect circles, some elongated ovals and some entirely irregular shapes with little or no symmetry - but they will have entirely curved boundaries, almost without exception. There are no fixed dimensions for the field but its diameter usually varies between 450 feet (137 m) and 500 feet (150 m). Within the boundary and generally as close to the centre as possible will be the square which is an area of carefully prepared grass upon which cricket pitches can be prepared and marked for matches.",width = NULL)
                                  ),
                         mainPanel(
                                  leafletOutput("mymap"),
                                  plotlyOutput("bar_stadium")
                                  )
                                 ) 
                  ),
            tabPanel("Team Analysis",
                  sidebarLayout(
                     sidebarPanel(
                       selectInput(inputId = "Team_ID","Team",selected = 'KKR',choices = c('CSK','DD','RR','RCB','SRH','MI','KXI','KKR')),
                       uiOutput("Team_image"),
                       tableOutput('team_tbl')
                                 ),
                        mainPanel(
                                  plotlyOutput("bar_team"),
                                  selectInput(inputId = "Year_ID4","Year",selected = 2017,choices = 2008:2017),
                                  plotlyOutput("scatter_team")
                                  
                                 )
                               ) 
                  )      
    )
  )

