############ Importing the required libraries
library(dplyr)
library(ggplot2) 
library(plotly)
library(dummies)

#### SETTING UP BY FILE IMPORT PATH
setwd("D:\\IPL\\IPL\\")


### IMPORT THE BALL BY BALL DATA
ball_by_ball<-read.csv("ball_by_ball_data.csv",header = T,sep = ",",stringsAsFactors = F)

match_df<-ball_by_ball%>%filter(is_super_over==0)%>%group_by(match_id,match_year,batting_team)%>%summarise(batsman_runs=sum(batsman_runs),extra_runs=sum(extra_runs))%>%mutate(total_runs=batsman_runs+extra_runs)

match_df$bat_first<-0
match_df$bat_second<-0
match_df$tied_no_result_super_over<-0

for (i in seq(1, nrow(match_df), 2)) {
  if(match_df[i,"total_runs"]>match_df[i+1,"total_runs"]){
    match_df[i,"bat_first"]=1
  }
  else if(match_df[i,"total_runs"]<match_df[i+1,"total_runs"]){
    match_df[i+1,"bat_second"]=1
  }
  else if(match_df[i,"total_runs"]==match_df[i+1,"total_runs"]){
    match_df[i,"tied_no_result_super_over"]=1 
  }  

}
match_df = subset(match_df, select = -c(match_id) )

match_df%>%select(match_year,bat_first,bat_second,tied_no_result_super_over)%>%group_by(match_year)%>%summarise_all(sum)

#### WRITING CSV 
write.csv(file="seasonal_bat_first_second.csv",x=match_df,row.names = F)
