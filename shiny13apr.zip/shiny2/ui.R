## ui.R

library(shiny)
library(plotly)

#setwd("E:\\shiny2")

batsmen_names<-read.csv("batsman_names.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)

batters<-unique(batsmen_names$Batsman)
batters<-sort(batters)

bowler_df<-read.csv("bowler_names.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)

Bowlers<-unique(bowler_df$Bowlers)
Bowlers<-sort(Bowlers)


title <- tags$a(href='https://www.iplt20.com/',
                tags$img(src="vivo-ipl-logo.png", height = '65', width = '125'))


ui<-fluidPage(theme = "bootstrap.min.css",
  navbarPage(title=title,
    #img(src='Indian_Premier_League_Logo.png', align = "right"),
             tabPanel("Seasonal Trends",  
                      sidebarLayout(
                          sidebarPanel(
                                selectInput(inputId = "Year_ID","Year",selected = 2017,choices = 2008:2017),
                                sliderInput(inputId="Num_Player_ID", label="Number of players", min=5, max=20,value=10),
                                "Winner",
                                uiOutput("Winner_image")
                                      ),
                            mainPanel(
                                plotlyOutput("bar_seasonal"),  
                                plotlyOutput("pie_seasonal")
                                      )
                                   )
                      ),
             tabPanel("Batsman Analysis",
                      sidebarLayout(
                          sidebarPanel(
                                
                                selectInput("batter_name", "Batsman Name:", 
                                            choices=batters),
                                uiOutput("batsman_image"),
                                selectInput(inputId = "Year_ID1","Year",selected = 2017,choices = 2008:2017)
                               
                                      ),
                       
                          mainPanel(
                              plotlyOutput("bar_batsman"),
                              plotlyOutput("pie_batsman")
                                    )
                                 )       
                     ),
            tabPanel("Bowler Analysis",
                     sidebarLayout(
                       sidebarPanel(
                         
                              selectInput("bowler_name", "Bowler Name:", 
                                     choices=Bowlers),
                              uiOutput("bowler_image"),
                              selectInput(inputId = "Year_ID2","Year",selected = 2017,choices = 2008:2017)
                                   ),
                        mainPanel(
                              plotlyOutput("bar_bowler")
                                 )
                                ) 
                    ),
            tabPanel("Stadium Analysis",
                    sidebarLayout(
                      sidebarPanel(
                           selectInput(inputId = "Year_ID3","Year",selected = 2017,choices = 2008:2017)
                                  ),
                         mainPanel(
                 
                                  )
                                 ) 
                  ),
            tabPanel("Team Analysis",
                  sidebarLayout(
                     sidebarPanel(
                            selectInput(inputId = "Year_ID4","Year",selected = 2017,choices = 2008:2017)
                                 ),
                        mainPanel(
                 
                                 )
                               ) 
                  )      
    )
  )

