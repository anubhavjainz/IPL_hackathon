## server.R
library(ggplot2)
library(shiny)
library(plotly)
library(dplyr)
library(reshape2)
#setwd("E:\\shiny2")

bowler_wickets<-read.csv("bowler_wickets.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)

batsmen_data_frame<-read.csv("batsmen_data_frame.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)

Yearly_IPL_Winner<-read.csv("Yearly_IPL_Winner.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)

Season_win_counts<-read.csv("Season_win_counts.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)

bowler_df<-read.csv("bowler_df.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)

shinyServer(function(input, output) {
  
  
  #season page
  output$Winner_image <- renderUI({
    tags$img(src = paste0(Yearly_IPL_Winner[Yearly_IPL_Winner$Year==input$Year_ID,'Winner'], ".png"),width = "200px", height = "200px")
  })
  
  output$bar_seasonal<-renderPlotly({
    t=head(batsmen_data_frame%>%filter(match_year==input$Year_ID),input$Num_Player_ID)
    t$batsman <- factor(t$batsman, levels = t$batsman)
    p1<-plot_ly( x = t$batsman,
      y =t$Total_runs,
      type = "bar",
     # text=t$average,
      color = I("orange"),
      name='Batsman')
    t=head(bowler_wickets%>%filter(match_year==input$Year_ID),input$Num_Player_ID)
    t$bowler <- factor(t$bowler, levels = t$bowler)
    p2<-plot_ly( x = t$bowler,
             y =t$Total_wickets,
             type = "bar",
             color = I("purple"),
             name='Bowler')
    
    p<-subplot(p1,p2)%>% layout(annotations = list(
      list(x = 0.2 , y = 1.05, text = "Top Run getters by Season", showarrow = F, xref='paper', yref='paper'),
      list(x = 0.8 , y = 1.05, text = "Top Wicket Takers by Season", showarrow = F, xref='paper', yref='paper'))
    )
    })  
  
  output$pie_seasonal<-renderPlotly({
      
      ds1<-Season_win_counts%>%filter(season==input$Year_ID)    
      
      
      dis_type<-batsmen_data_frame[c("match_year","bowled","caught","caught.and.bowled","lbw","run.out","stumped")]
      t2<-dis_type%>%filter(match_year==input$Year_ID)%>%group_by("match_year")%>%summarise_all(sum)    
      ds2<-melt(data = t2, id.vars = c("match_year"), measure.vars = c("bowled","caught","caught.and.bowled","lbw","run.out","stumped"))
      colnames(ds2)[colnames(ds2)=="variable"] <- "variable1"
      colnames(ds2)[colnames(ds2)=="value"] <- "value1"
      
      p1 <- plot_ly()%>%add_pie(name="Team_matches",labels = ds1$winner,textposition = 'inside',
                                textinfo = 'label+percent',
                                insidetextfont = list(color = '#FFFFFF'), values = ds1$Number_of_matches_won,domain = list(row = 0, column = 0),name='Team_matches')%>%
        add_pie(name="Dismissal Type", labels = ds2$variable1, values = ds2$value1,textposition = 'inside',
                textinfo = 'label+percent',
                insidetextfont = list(color = '#FFFFFF'),domain = list(row = 0, column = 1),name='Dismissal')%>%
        layout(title = "Team matches won                                                                                        Dismissal Type", showlegend = F,
               grid=list(rows=1, columns=2),
               xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
               yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
   })  
  
  
  
  
  #batsman page
  output$bar_batsman<-renderPlotly({
      ay2<-list(zeroline = FALSE,
                showline = FALSE,
                showticklabels = FALSE,
                showgrid = FALSE)
      ay <- list(
      tickfont = list(color = "red"),
      overlaying = "y",
      side = "right",
      title = "",
      zeroline = FALSE,
      showline = FALSE,
      showticklabels = FALSE,
      showgrid = FALSE
    )
      t=batsmen_data_frame%>%filter(batsman==input$batter_name)
      p1<-plot_ly( x = t$match_year)%>%
          add_trace(y =t$Total_runs,
                 type = "bar",
                 # text=t$average,
                 color = I("orange"),
                 name='Total')%>%
        add_trace(   y = t$average, 
                     type = 'scatter', 
                     mode = 'lines+markers',
                     color = I("red"),
                     name='Average',
                     yaxis = "y2")%>%
        add_trace(   y = t$Strike_Rate, 
                     type = 'scatter', 
                     mode = 'lines+markers',
                     color = I("blue"),
                     name='Strike_Rate',
                     yaxis = "y2")%>% layout(yaxis=ay2,
                        yaxis2 = ay,
                       xaxis = list(title="Year")
                     )
    
  })
  output$pie_batsman<-renderPlotly({
    bat_score<-batsmen_data_frame[c("batsman","match_year", "Thirties","Fifties","Hundreds")]
    t1<-bat_score%>%filter(match_year==input$Year_ID1&batsman==input$batter_name)    
    ds1<-melt(data = t1, id.vars = c("match_year"), measure.vars = c("Thirties","Fifties","Hundreds"))
    
    
    dis_type<-batsmen_data_frame[c("batsman","match_year","bowled","caught","caught.and.bowled","lbw","run.out","stumped")]
    t2<-dis_type%>%filter(match_year==input$Year_ID1&batsman==input$batter_name)   
    ds2<-melt(data = t2, id.vars = c("match_year"), measure.vars = c("bowled","caught","caught.and.bowled","lbw","run.out","stumped"))
    colnames(ds2)[colnames(ds2)=="variable"] <- "variable1"
    colnames(ds2)[colnames(ds2)=="value"] <- "value1"
    
    p1 <- plot_ly()%>%add_pie(name="Number of Milestones",labels = ds1$variable, values = ds1$value,textposition = 'inside',
                              textinfo = 'label+percent',
                              insidetextfont = list(color = '#FFFFFF'),domain = list(row = 0, column = 0),name='Milestone')%>%
      add_pie(hole = 0.5,name="Dismissal Type", labels = ds2$variable1, values = ds2$value1,textposition = 'inside',
              textinfo = 'label+percent',
              insidetextfont = list(color = '#FFFFFF'),domain = list(row = 0, column = 1),name='Dismissal')%>%
      layout(title = "Number of Milestones                                                                                        Dismissal Type", showlegend = F,
             grid=list(rows=1, columns=2),
             xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
             yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
  }) 

  output$batsman_image <- renderUI({
    tags$img(src = paste0(input$batter_name, ".png"),width = "284px", height = "284px")
  })
  
  

  
  
  
  
  #bowler page
  output$bar_bowler<-renderPlotly({
    ay2<-list(zeroline = FALSE,
              showline = FALSE,
              showticklabels = FALSE,
              showgrid = FALSE)
    ay <- list(
      tickfont = list(color = "red"),
      overlaying = "y",
      side = "right",
      title = "",
      zeroline = FALSE,
      showline = FALSE,
      showticklabels = FALSE,
      showgrid = FALSE
    )
    t=bowler_df%>%filter(bowler==input$bowler_name)
    #names(bowler_df)
    t<-t[c("match_year","Runs_Conceded","Extras_Conceded", "Balls","Total_Wickets"  )]
    df<-t%>%group_by(match_year)%>%mutate(Matches=1)%>%summarise_all(sum)%>%mutate(Season_Economy=(Runs_Conceded/Balls)*6)
    p1<-plot_ly( x = df$match_year)%>%
      add_trace(y =df$Matches,
                type = "bar",
                # text=t$average,
                color = I("blue"),
                name='Total Matches')%>%
      add_trace(y = df$Total_Wickets,type="bar" ,name = 'Total_Wickets', color = I("purple")) %>%
      add_trace(   y = df$Season_Economy, 
                   type = 'scatter', 
                   mode = 'lines+markers',
                   color = I("red"),
                   name='Economy',
                   yaxis = "y2")%>%
      add_trace(   y = df$Extras_Conceded, 
                   type = 'scatter', 
                   mode = 'lines+markers',
                   color = I("yellow"),
                   name='Extras_Conceded',
                   yaxis = "y2")%>% layout(yaxis=ay2,
                                           yaxis2 = ay,
                                           xaxis = list(title="Year")
                   )
    
  })
  
  output$bowler_image <- renderUI({
    tags$img(src = paste0(input$bowler_name, ".png"),width = "284px", height = "284px")
  })
})


