## ui.R

library(shiny)
library(plotly)
shinyUI(
  navbarPage("My Application",
             tabPanel(
               "Component 1",  sidebarLayout(sidebarPanel(selectInput(inputId = "n","Year",choices = 2008:2017),
                                                          sliderInput(inputId="nu", label="Number of players", min=5, max=20,value=10)),
    mainPanel(
                  plotlyOutput("bar2"),  plotlyOutput("bar")))
),
tabPanel("Component 2"),
tabPanel("Component 3")))


