## server.R
library(ggplot2)
library(shiny)
library(plotly)
library(dplyr)
setwd("E:\\shiny2\\train")
batsmen_runs<-read.csv("batsmen_runs.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)

bowler_wickets<-read.csv("bowler_wickets.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)

shinyServer(function(input, output) {

 
  output$bar2<-renderPlotly({
    t=head(batsmen_runs%>%filter(match_year==input$n),input$nu)
    t$batsman <- factor(t$batsman, levels = t$batsman)
    plot_ly( x = t$batsman,
      y =t$Total_runs,
      name = "SF Zoo",
      type = "bar",
      color = "red"
    )
    
    })  
  
  output$bar<-renderPlotly({
    t=head(bowler_wickets%>%filter(match_year==input$n),input$nu)
    t$bowler <- factor(t$bowler, levels = t$bowler)
    plot_ly( x = t$bowler,
             y =t$Total_wickets,
             name = "SF Zoo",
             type = "bar",
             color = "#9467bd"
    )
    
  })  
})


