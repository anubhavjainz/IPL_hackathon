library("leaflet")
library(maps)
setwd("E:\\shiny2")

match_data<-read.csv("match_data.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)

unique(match_data$city)

library(dplyr)
stadium<-match_data%>%group_by(season,city,venue)%>%summarise(matches=n())


stadium[is.na(stadium$city),'city']='Dubai'

stadium[stadium$city=='Mumbai',"city"]='Bombay'

stadium[stadium$city=='Kolkata',"city"]='Calcutta'
stadium[stadium$city=='Ahmedabad',"city"]='Ahmadabad'
stadium[stadium$city=='Dharamsala',"city"]='Shimla'
stadium[stadium$city=='Cuttack',"city"]='Bhubaneswar'
stadium[stadium$city=='Centurion',"city"]='Pretoria'


data("world.cities")
View(world.cities)

cities<-world.cities%>%filter( country.etc!='Canada')
cities<-cities%>%filter( country.etc!='New Zealand')
cities<-cities%>%filter( country.etc!='Pakistan')
cities<-cities%>%filter( country.etc!='UK')
cities<-cities%>%filter( country.etc!='Saint Vincent and The Grenadines')
cities<-cities%>%filter( country.etc!='Japan')



stadia<-left_join(x=stadium,y=cities,by=c("city"="name"))

stadia[stadia$city=='Shimla',"city"]='Dharamsala'
stadia[stadia$city=='Bhubaneswar',"city"]='Cuttack'
stadia[stadia$city=='Calcutta',"city"]='Kolkata'
stadia[stadia$city=='Bombay',"city"]='Mumbai'
stadia[stadia$city=='Pretoria',"city"]='Centurion'



write.csv(x=stadia,file='stadium_df.csv',row.names = F)


