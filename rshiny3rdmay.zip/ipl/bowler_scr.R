############ Importing the required libraries
library(dplyr)
library(ggplot2) 
library(plotly)
library(dummies)

#### SETTING UP BY FILE IMPORT PATH
setwd("E:\\shiny2")

### IMPORT THE BALL BY BALL DATA
ball_by_ball<-read.csv("ball_by_ball_data.csv",header = T,sep = ",",stringsAsFactors = F)


### BoWLER WICKETS BY SEASON
bowler_wickets<-ball_by_ball%>%filter(is_super_over==0)%>%filter(!is.na(player_dismissed))%>%group_by(match_year,match_id,bowler)%>%summarise(Total_Wickets=n())%>%arrange(match_year,match_id,desc(Total_Wickets))

### BOLWER ECONOMY BY SEASON
bowler_economy<-ball_by_ball%>%filter(is_super_over==0)%>%mutate(Runs_scored=batsman_runs+extra_runs)%>%group_by(match_year,match_id,bowler)%>%summarise(Runs_Conceded=sum(Runs_scored),Extras_Conceded=sum(extra_runs),Balls=floor(n()/6)*6,Match_Economy=(sum(Runs_scored)/(floor(n()/6)*6))*6)


names(bowler_economy)


### BOWLER DF

bowler_df<-left_join(x=bowler_economy,y=bowler_wickets,by=c("match_year","match_id","bowler"))

bowler_df[is.na(bowler_df)] <- 0


write.csv(bowler_df,file="bowler_df.csv",row.names = F)



###SEASON WIN COUNT


match_data<-read.csv("match_data.csv",header = T,sep = ",",stringsAsFactors = F)

Season_win_counts<-match_data%>%group_by(season,winner)%>%summarise(Number_of_matches_won=n())


write.csv(Season_win_counts,file="Season_win_counts.csv",row.names = F)
