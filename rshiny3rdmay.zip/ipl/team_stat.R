setwd("E:\\shiny2")

library(ggplot2)
library(shiny)
library(plotly)
library(dplyr)
library(reshape2)

ball_by_ball<-read.csv("ball_by_ball_data.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)

match_data<-read.csv("match_data.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)

names(match_data)

match_data<-match_data[c("match_id","city","toss_winner","toss_decision","result","winner","win_by_runs","win_by_wickets","player_of_match", "venue"   )]

Team_stats<-ball_by_ball%>%filter(is_super_over==0)%>%group_by(match_year,match_id,inning,batting_team,bowling_team)%>%summarise(Innings_score=sum(batsman_runs))


Team_final<-left_join(x=Team_stats,y=match_data,by='match_id')

Team_final$win_flag=ifelse(Team_final$batting_team==Team_final$winner,'Y','N')

Team_final$win=ifelse(Team_final$win_flag=='Y',1,0)

Team_final$loss=ifelse(Team_final$win_flag=='N',1,0)


write.csv(x=Team_final,file = "Team_final.csv",row.names = F)
