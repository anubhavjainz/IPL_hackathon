## ui.R


#### Importing the required libraries
library(shiny)
library(plotly)
library(shinydashboard)
library(leaflet)
library(r2d3)


### Setting up the working directories
setwd("D:\\IPL\\IPL")


### Importing files for the drop dowm input

### Batsmen Names
batsmen_names<-read.csv("batsman_names.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)

batters<-unique(batsmen_names$Batsman)
batters<-sort(batters)

### Bowler Names
bowler_df<-read.csv("bowler_names.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)

Bowlers<-unique(bowler_df$Bowlers)
Bowlers<-sort(Bowlers)




### IPL Title Icon
title <- tags$a(href='https://www.iplt20.com/',
                tags$img(src="vivo-ipl-logo.png", height = '65', width = '125'))


### START of UI function
ui<-fluidPage(theme = "bootstrap.min.css",   ### CSS file 
  navbarPage(title=title,
             #### SEASONAL TRENDS PANE
             tabPanel("Seasonal Trends",  
                      sidebarLayout(
                          sidebarPanel(
                                selectInput(inputId = "Year_ID","Year",selected = 2017,choices = 2008:2017),
                                sliderInput(inputId="Num_Player_ID", label="Number of players", min=5, max=20,value=10),
                                "Winner",
                                uiOutput("Winner_image"),
                                fluidRow(
                                  # A static infoBox
                                  shinydashboard:::valueBox(636,"Matches Played",width = NULL),
                                  shinydashboard:::valueBox(13,"Teams participated till now",width = NULL),
                                  shinydashboard:::valueBox(85,"Mumbai hosted most number of IPL matches",width = NULL)
                                )
                                      ),
                            mainPanel(   
                                plotlyOutput("bar_seasonal"),  
                                plotlyOutput("pie_seasonal")
                                      )
                                   )
                      ),
             tabPanel("Batsman Analysis",
                      sidebarLayout(
                          sidebarPanel(
                                
                                selectInput("batter_name", "Batsman Name:", 
                                            choices=batters),
                                
                                uiOutput("batsman_image"),
                                tableOutput('batter_tbl')
                               
                                      ),
                       
                          mainPanel(
                              plotlyOutput("bar_batsman"),
                              selectInput(inputId = "Year_ID1","Season",selected = 2017,choices = 2008:2017),
                              plotlyOutput("pie_batsman")
                                    )
                                 )       
                     ),
            tabPanel("Bowler Analysis",
                     sidebarLayout(
                       sidebarPanel(
                         
                              selectInput("bowler_name", "Bowler Name:", 
                                     choices=Bowlers),
                              uiOutput("bowler_image"),
                              #selectInput(inputId = "Year_ID2","Year",selected = 2017,choices = 2008:2017),
                              tableOutput('bowler_tbl')
                                   ),
                        mainPanel(
                              plotlyOutput("bar_bowler")
                                 )
                                ) 
                    ),
            tabPanel("Stadium Analysis",
                    sidebarLayout(
                      sidebarPanel(
                           selectInput(inputId = "Year_ID3","Year",selected = 2017,choices = 2008:2017)
                                  ),
                         mainPanel(
                                  leafletOutput("mymap"),
                                  plotlyOutput("bar_stadium")
                                  )
                                 ) 
                  ),
            tabPanel("Team Analysis",
                  sidebarLayout(
                     sidebarPanel(
                       selectInput(inputId = "Team_ID","Team",selected = 'KKR',choices = c('CSK','DD','RR','RCB','SRH','MI','KXI','KKR')),
                       uiOutput("Team_image"),
                       tableOutput('team_tbl'),
                        selectInput(inputId = "Year_ID4","Year",selected = 2017,choices = 2008:2017)
                                 ),
                        mainPanel(
                                  plotlyOutput("bar_team")
                                 )
                               ) 
                  )      
    )
  )

