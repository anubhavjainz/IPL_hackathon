## ui.R

library(shiny)
library(plotly)

setwd("D:\\shiny22\\shiny2\\train\\")

batsmen_data_frame<-read.csv("batsmen_data_frame.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)


shinyUI(
  navbarPage("VIVO IPL",
             tabPanel("Seasonal Trends",  
                      sidebarLayout(
                          sidebarPanel(
                                selectInput(inputId = "Year_ID","Year",choices = 2008:2017),
                                sliderInput(inputId="Num_Player_ID", label="Number of players", min=5, max=20,value=10)
                                      ),
                            mainPanel(
                                plotlyOutput("bar_seasonal"),  
                                plotlyOutput("pie_seasonal")
                                      )
                                   )
                      ),
             tabPanel("Batsman Analysis",
                      sidebarLayout(
                          sidebarPanel(
                                selectInput(inputId = "Year_ID1","Year",choices = 2008:2017),
                                selectInput("batter_name", "Batsman Name:", 
                                            choices=unique(batsmen_data_frame$batsman))
                                
                                      ),
                       
                          mainPanel(
                              plotlyOutput("bar_batsman"),
                              plotlyOutput("pie_batsman")
                                    )
                                 )       
                     ),
tabPanel("Component 3")))

