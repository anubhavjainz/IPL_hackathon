############ Importing the required libraries
library(dplyr)
library(ggplot2) 
library(plotly)
library(dummies)

#### SETTING UP BY FILE IMPORT PATH
setwd("D:\\shiny22\\shiny2\\train")


### IMPORT THE BALL BY BALL DATA
ball_by_ball<-read.csv("ball_by_ball_data.csv",header = T,sep = ",",stringsAsFactors = F)


### BATSMAN RUNS BY SEASON
batsmen_runs<-ball_by_ball%>%filter(is_super_over==0)%>%group_by(batsman,match_year)%>%summarise(Total_runs=sum(batsman_runs))%>%arrange(match_year,desc(Total_runs))
 

### BATSMAN DISMISSALS BY SEASON
batsmen_dismissals<-ball_by_ball%>%filter(!is.na(player_dismissed))%>%group_by(player_dismissed,match_year)%>%summarise(Dismissals=n())


### NUMBER OF DELIVERIES FACED BY BATSMAN BY SEASON
batsmen_balls_faced<-ball_by_ball%>%filter(is_super_over==0)%>%group_by(batsman,match_year)%>%summarise(Balls_faced=n())


### BATSMAN RUNS BY MATCH IN A SEASON
batsmen_runs_match_wise<-ball_by_ball%>%filter(is_super_over==0)%>%group_by(batsman,match_id,match_year)%>%summarise(Runs_scored=sum(batsman_runs))


### NUMBER OF THIRTIES, FIFTIES AND HUNDREDS CALCULATION PER SEASON
batsmen_runs_match_wise$Thirties<-ifelse(batsmen_runs_match_wise$Runs_scored>=30,1,0)

batsmen_runs_match_wise$Fifties<-ifelse(batsmen_runs_match_wise$Runs_scored>=50,1,0)

batsmen_runs_match_wise$Hundreds<-ifelse(batsmen_runs_match_wise$Runs_scored>=100,1,0)

batsmen_runs_match_wise$Thirties<-ifelse(batsmen_runs_match_wise$Fifties==1,0,batsmen_runs_match_wise$Thirties)

batsmen_runs_match_wise$Fifties<-ifelse(batsmen_runs_match_wise$Hundreds==1,0,batsmen_runs_match_wise$Fifties)

names(batsmen_runs_match_wise)

batsmen_runs_match_agg<-batsmen_runs_match_wise

batsmen_runs_match_agg<-batsmen_runs_match_agg[c("batsman","match_year","Thirties","Fifties","Hundreds")]

batsmen_T_F_H<-batsmen_runs_match_agg%>%group_by(batsman,match_year)%>%summarise_all(sum)


### TYPE OF BATSMAN DISMISSAL
batsmen_dismissal_kind<-ball_by_ball%>%filter(!is.na(player_dismissed))

dummy_df<-dummy(batsmen_dismissal_kind$dismissal_kind)

colnames(dummy_df)<-gsub("dismissal_kind", "", colnames(dummy_df))

batsmen_dismissal_kind<-cbind(batsmen_dismissal_kind,dummy_df)

colnames(batsmen_dismissal_kind)

batsmen_dismissal_kind<-batsmen_dismissal_kind[c("player_dismissed","match_year","bowled","caught","caught and bowled","lbw","run out", "stumped" )]

batsmen_dismissal_kind<-batsmen_dismissal_kind%>%group_by(player_dismissed,match_year)%>%summarise_all(sum)


### 





### JOINING ALL THE DATA FRAMES TO ONE 

batsmen_df<-left_join(x=batsmen_runs,y=batsmen_dismissals,by=c("batsman"="player_dismissed","match_year"))

batsmen_df<-na.omit(batsmen_df)

batsmen_df$average<-batsmen_df$Total_runs/batsmen_df$Dismissals



batsmen_df<-left_join(x=batsmen_df,y=batsmen_balls_faced,by=c("batsman","match_year"))

batsmen_df$Strike_Rate=batsmen_df$Total_runs/batsmen_df$Balls_faced*100



batsmen_df<-left_join(x=batsmen_df,y=batsmen_T_F_H,by=c("batsman","match_year"))



batsmen_df<-left_join(x=batsmen_df,y=batsmen_dismissal_kind,by=c("batsman"="player_dismissed","match_year"))


#### WRITING CSV 
write.csv(file="batsmen_data_frame.csv",x=batsmen_df,row.names = F)
