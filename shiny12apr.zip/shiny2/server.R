## server.R
library(ggplot2)
library(shiny)
library(plotly)
library(dplyr)
library(reshape2)
setwd("D:\\shiny22\\shiny2\\train\\")

bowler_wickets<-read.csv("bowler_wickets.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)

batsmen_data_frame<-read.csv("batsmen_data_frame.csv",header = T,sep = ",",na.strings = "",stringsAsFactors = F)


shinyServer(function(input, output) {

 
  output$bar_seasonal<-renderPlotly({
    t=head(batsmen_data_frame%>%filter(match_year==input$Year_ID),input$Num_Player_ID)
    t$batsman <- factor(t$batsman, levels = t$batsman)
    p1<-plot_ly( x = t$batsman,
      y =t$Total_runs,
      type = "bar",
     # text=t$average,
      color = I("orange"),
      name='Batsman')
    t=head(bowler_wickets%>%filter(match_year==input$Year_ID),input$Num_Player_ID)
    t$bowler <- factor(t$bowler, levels = t$bowler)
    p2<-plot_ly( x = t$bowler,
             y =t$Total_wickets,
             type = "bar",
             color = I("purple"),
             name='Bowler')
    
    p<-subplot(p1,p2)%>% layout(annotations = list(
      list(x = 0.2 , y = 1.05, text = "Top Run getters by Season", showarrow = F, xref='paper', yref='paper'),
      list(x = 0.8 , y = 1.05, text = "Top Wicket Takers by Season", showarrow = F, xref='paper', yref='paper'))
    )
    })  
  
  output$pie_seasonal<-renderPlotly({
      bat_score<-batsmen_data_frame[c("match_year", "Thirties","Fifties","Hundreds")]
      t1<-bat_score%>%filter(match_year==input$Year_ID)%>%group_by("match_year")%>%summarise_all(sum)    
      ds1<-melt(data = t1, id.vars = c("match_year"), measure.vars = c("Thirties","Fifties","Hundreds"))
      
      
      dis_type<-batsmen_data_frame[c("match_year","bowled","caught","caught.and.bowled","lbw","run.out","stumped")]
      t2<-dis_type%>%filter(match_year==input$Year_ID)%>%group_by("match_year")%>%summarise_all(sum)    
      ds2<-melt(data = t2, id.vars = c("match_year"), measure.vars = c("bowled","caught","caught.and.bowled","lbw","run.out","stumped"))
      colnames(ds2)[colnames(ds2)=="variable"] <- "variable1"
      colnames(ds2)[colnames(ds2)=="value"] <- "value1"
      
      p1 <- plot_ly()%>%add_pie(name="Number of Milestones",labels = ds1$variable, values = ds1$value,domain = list(x = c(0, 0.4), y = c(0.2, 1)))%>%
        add_pie(name="Dismissal Type", labels = ds2$variable1, values = ds2$value1,domain = list(x = c(0.6, 1), y = c(0.2, 1)))%>%
        layout(title = "Number of Milestones                                                                                        Dismissal Type", showlegend = F,
               xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
               yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
   })  
  output$bar_batsman<-renderPlotly({
      ay2<-list(zeroline = FALSE,
                showline = FALSE,
                showticklabels = FALSE,
                showgrid = FALSE)
      ay <- list(
      tickfont = list(color = "red"),
      overlaying = "y",
      side = "right",
      title = "",
      zeroline = FALSE,
      showline = FALSE,
      showticklabels = FALSE,
      showgrid = FALSE
    )
      t=batsmen_data_frame%>%filter(batsman==input$batter_name)
      p1<-plot_ly( x = t$match_year)%>%
          add_trace(y =t$Total_runs,
                 type = "bar",
                 # text=t$average,
                 color = I("orange"),
                 name='Total')%>%
        add_trace(   y = t$average, 
                     type = 'scatter', 
                     mode = 'lines+markers',
                     color = I("red"),
                     name='Average',
                     yaxis = "y2")%>%
        add_trace(   y = t$Strike_Rate, 
                     type = 'scatter', 
                     mode = 'lines+markers',
                     color = I("blue"),
                     name='Strike_Rate',
                     yaxis = "y2")%>% layout(yaxis=ay2,
                        yaxis2 = ay,
                       xaxis = list(title="Year")
                     )
    
  })
  output$pie_batsman<-renderPlotly({
    bat_score<-batsmen_data_frame[c("batsman","match_year", "Thirties","Fifties","Hundreds")]
    t1<-bat_score%>%filter(match_year==input$Year_ID1&batsman==input$batter_name)    
    ds1<-melt(data = t1, id.vars = c("match_year"), measure.vars = c("Thirties","Fifties","Hundreds"))
    
    
    dis_type<-batsmen_data_frame[c("batsman","match_year","bowled","caught","caught.and.bowled","lbw","run.out","stumped")]
    t2<-dis_type%>%filter(match_year==input$Year_ID1&batsman==input$batter_name)   
    ds2<-melt(data = t2, id.vars = c("match_year"), measure.vars = c("bowled","caught","caught.and.bowled","lbw","run.out","stumped"))
    colnames(ds2)[colnames(ds2)=="variable"] <- "variable1"
    colnames(ds2)[colnames(ds2)=="value"] <- "value1"
    
    p1 <- plot_ly()%>%add_pie(name="Number of Milestones",labels = ds1$variable, values = ds1$value,domain = list(x = c(0, 0.4), y = c(0.2, 1)))%>%
      add_pie(name="Dismissal Type", labels = ds2$variable1, values = ds2$value1,domain = list(x = c(0.6, 1), y = c(0.2, 1)))%>%
      layout(title = "Number of Milestones                                                                                        Dismissal Type", showlegend = F,
             xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
             yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
  }) 
})


